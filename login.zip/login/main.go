package main

import (
	"fmt"
	"net/http"
)

func indexHandler(w http.ResponseWriter, r *http.Request) {
	http.SetCookie(w, &http.Cookie{
		Name:   "user",
		Value:  "admin",
		Path:   "/",
		MaxAge: 60 * 2,
	})

	fmt.Fprintf(w, "ok")
}

func main() {
	http.HandleFunc("/login", indexHandler)
	http.ListenAndServe(":8001", nil)
}
